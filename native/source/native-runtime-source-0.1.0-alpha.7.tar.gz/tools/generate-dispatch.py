#!/usr/bin/env python3
"""Generate native-runtime/src/generated.base.rs (typed worker dispatch and model
validation) from native-runtime/api-metadata.json and the vendored crate contracts.

Deterministic, standard library only. `--check` compares byte-for-byte.
"""
import argparse, json, re
from pathlib import Path

JSON_RESULT = 'Ok(object(vec![("kind","json".into()),("value",result.to_json().map_err(|_| failure("response_schema","Typed response serialization failed."))?)]))'
CLIENTS = {
    'NfeClient': 'let client = sdk::NfeClient::with_config(companycredentials(v)?,config).map_err(error)?;',
    'ResellerClient': 'let client = sdk::ResellerClient::with_config(resellercredentials(v)?,config).map_err(error)?;',
    'EmitterClient': 'let client = sdk::EmitterClient::with_config(issuertoken(v)?,config).map_err(error)?;',
    'MonitorClient': 'let client = sdk::MonitorClient::with_config(monitortoken(v)?,config).map_err(error)?;',
    'NfeFilesClient': 'let cred = if v.get("credentials").is_some_and(|x| !x.is_null()) { Some(companycredentials(v)?) } else {None};\nlet client = sdk::NfeFilesClient::new(cred,config).map_err(error)?;',
    'EmitterFilesClient': 'let cred = if v.get("credentials").is_some_and(|x| !x.is_null()) { Some(issuertoken(v)?) } else {None};\nlet client = sdk::EmitterFilesClient::new(cred,config).map_err(error)?;',
}


def sdk_type(rust):
    return rust.lstrip('&').replace('crate::', 'sdk::')


def esc_ptr(token):
    return str(token).replace('~', '~0').replace('/', '~1')


def dispatch_arm(op, unavailable):
    out = ['"%s" => {' % op['id'], 'require_scope(v,"%s")?;' % op['scope'], 'let config = config(v,token)?;', CLIENTS[op['client']]]
    path_names = [p['name'] for p in op['path_params']]
    args, lets, path_index = [], {}, 0
    for p in op['params']:
        t = p['type']
        if t in ('&str', 'i64'):
            reader = 'text' if t == '&str' else 'integer'
            args.append('%s(required(v,"path")?,"%s")?' % (reader, path_names[path_index]))
            path_index += 1
        elif t == '&crate::FileAuth':
            lets['auth'] = 'let auth = file_auth(v)?;'
            args.append('&auth')
        elif p['name'] in ('body', 'query'):
            lets[p['name']] = 'let %s: %s = FromJson::from_json(required(v,"%s")?).map_err(|_| failure("validation","Invalid typed model."))?;' % (p['name'], sdk_type(t), p['name'])
            args.append('&' + p['name'])
        else:
            raise SystemExit('unsupported parameter %s of %s' % (p, op['id']))
    for key in ('body', 'query', 'auth'):
        if key in lets:
            out.append(lets[key])
    out.append('let result = client.%s(%s).map_err(error)?;' % (op['method'], ','.join(args)))
    if op['returns'] == 'crate::FileResponse':
        out.append('Ok(file(result))')
    elif op['returns'] == 'crate::FileOrRedirect':
        out.append('Ok(match result {sdk::FileOrRedirect::File(f)=>file(f),sdk::FileOrRedirect::Pending(p)=>pending(p)?,sdk::FileOrRedirect::Redirect(r)=>object(vec![("kind", "redirect".into()),("protected_location",r.location().reveal().into())])})')
    else:
        out.append(JSON_RESULT)
    out.append('},')
    return out


def query_pointers(op, contract):
    route = op['path']
    item = contract['paths'][route]
    spec = item[op['verb'].lower()]
    params = item.get('parameters', []) + spec.get('parameters', [])
    base = '#/paths/' + esc_ptr(route) + '/' + op['verb'].lower()
    return {p['name']: '%s/parameters/%d/schema' % (base, i) for i, p in enumerate(params) if p['in'] == 'query'}


def validate_arm(model, query_ops, contracts):
    key = '%s::%s' % (model['module'], model['name'])
    path = 'sdk::models::%s::%s' % (model['module'], model['name'])
    if model['pointer'] is None:
        op = query_ops[model['name']]
        pointers = query_pointers(op, contracts[op['module']])
        checks = ''.join('"%s"=>{if !sdk::contracts::validate(sdk::contracts::Module::from_name("%s").unwrap(),"%s",x){return Err(failure("validation","Query does not match pinned contract."));}},' % (name, op['module'], pointers[name]) for name in op['query_schema']['properties'])
        return '"%s" => {let map=value.as_object().ok_or_else(||failure("validation","Expected query object."))?;for(k,x)in map.iter(){match k {%s_=>return Err(failure("validation","Undeclared query member.")),}} let model = <%s as FromJson>::from_json(value).map_err(|_|failure("validation","Invalid query model."))?; Ok(object(vec![("kind","json".into()),("value",model.to_json().map_err(|_|failure("validation","Invalid query model."))?)]))},' % (key, checks, path)
    if model['kind'] == 'enum':
        variants = ','.join('%s::%s%s=>"%s"' % (path, f['name'], '' if f['type'] == 'Null' else '(_)', f['name']) for f in model['fields'])
        return '"%s" => {let model = <%s as Model>::from_value(value).map_err(error)?; let variant = match &model {%s}; Ok(object(vec![("kind","json".into()),("value",model.to_value().map_err(error)?),("variant",variant.into())]))},' % (key, path, variants)
    return '"%s" => {let model = <%s as Model>::from_value(value).map_err(error)?;  Ok(object(vec![("kind","json".into()),("value",model.to_value().map_err(error)?)]))},' % (key, path)


def generate(runtime, sdk_dir, unavailable_message):
    meta = json.loads((runtime / 'api-metadata.json').read_bytes())
    contracts = {p.stem: json.loads(p.read_bytes()) for p in sorted((sdk_dir / 'contracts').glob('*.json'))}
    blocked = [o['id'] for o in meta['operations'] if not o['enabled']]
    lines = ['// Generated from exact packaged public Rust methods.', 'fn dispatch(v: &Value, token: CancellationToken) -> R<Value> {', 'let op = text(v,"operation")?;']
    for op_id in blocked:
        lines.append('if op == "%s" { return Err(failure("capability","%s")); }' % (op_id, unavailable_message))
    lines.append('match op {')
    for op in meta['operations']:
        lines += dispatch_arm(op, unavailable_message)
    lines += ['_ => Err(failure("capability","Unknown operation.")),', '}}']
    query_ops = {}
    for op in meta['operations']:
        for p in op['params']:
            if p['name'] == 'query':
                query_ops[sdk_type(p['type']).rsplit('::', 1)[1]] = op
    lines.append('fn validate(v:&Value)->R<Value> {let value=required(v,"value")?; match text(v,"model")? {')
    for model in meta['models']:
        lines.append(validate_arm(model, query_ops, contracts))
    lines += ['_=>Err(failure("capability","Unknown model.")),}}', '']
    return '\n'.join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--runtime', type=Path, required=True)
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--unavailable-message', default='Operation not available in this SDK release.')
    a = ap.parse_args()
    crates = sorted(a.runtime.glob('vendor/webmania-sdk-*'))
    if len(crates) != 1:
        raise SystemExit('expected exactly one vendored webmania-sdk crate')
    text = generate(a.runtime, crates[0], a.unavailable_message)
    target = a.runtime / 'src/generated.base.rs'
    if a.check:
        if target.read_text() != text:
            raise SystemExit('generated dispatch differs: ' + str(target))
    else:
        target.write_text(text)


if __name__ == '__main__':
    main()
