//! Isolated, single-call worker. No HTTP engine is implemented here.
#![deny(unsafe_code)]
use webmania_sdk as sdk;
use sdk::{json::{Value,Map},model::{FromJson,ToJson},Model,CancellationToken};
use std::io::{Read,Write};
use std::os::fd::AsFd;
type R<T> = Result<T,Value>;
mod projection;
const INPUT_MAX:usize=32*1024*1024;
const OUTPUT_MAX:usize=40*1024*1024;
fn object(entries:Vec<(&str,Value)>)->Value {let mut m=Map::new();for (k,v) in entries {m.insert(k,v);} Value::Object(m)}
fn failure(kind:&str,message:&str)->Value {object(vec![("kind",kind.into()),("message",message.into())])}
fn required<'a>(v:&'a Value,k:&str)->R<&'a Value>{v.get(k).ok_or_else(||failure("validation","Missing protocol member."))}
fn text<'a>(v:&'a Value,k:&str)->R<&'a str>{required(v,k)?.as_str().ok_or_else(||failure("validation","Expected text."))}
fn integer(v:&Value,k:&str)->R<i64>{required(v,k)?.as_i64().ok_or_else(||failure("validation","Expected integer."))}
fn error(e:sdk::Error)->Value {
 let mut m=Map::new();m.insert("kind",e.kind().as_str());m.insert("message",e.message());
 if let Some(x)=e.status(){m.insert("status",i64::from(x));}
 if e.outcome().is_some(){m.insert("outcome","unknown");}
 if let Some(x)=e.recovery(){m.insert("protected_recovery",Value::Object(x.reveal_object()));}
 if let Some(x)=e.location(){m.insert("protected_location",x.reveal());}
 if let Some(x)=e.correlation_id(){m.insert("correlation_id",x);}
 if let Some(x)=e.request_id(){m.insert("request_id",x);}
 if let Some(x)=e.operation(){m.insert("operation",x);}
 if let Some(x)=e.details(){m.insert("details",x.clone());}
 Value::Object(m)
}
fn require_scope(v:&Value,s:&str)->R<()> {if text(v,"client_scope")?!=s {Err(failure("configuration","Client scope mismatch."))}else{Ok(())}}
fn credentials<'a>(v:&'a Value,kind:&str)->R<&'a Value>{let c=required(v,"credentials")?;if text(c,"kind")?!=kind{return Err(failure("configuration","Credential scope mismatch."));}Ok(c)}
fn companycredentials(v:&Value)->R<sdk::CompanyCredentials>{let c=credentials(v,"company")?;sdk::CompanyCredentials::new(text(c,"consumer_key")?,text(c,"consumer_secret")?,text(c,"access_token")?,text(c,"access_token_secret")?).map_err(error)}
fn resellercredentials(v:&Value)->R<sdk::ResellerCredentials>{let c=credentials(v,"reseller")?;sdk::ResellerCredentials::new(text(c,"consumer_key")?,text(c,"consumer_secret")?,text(c,"access_token")?,text(c,"access_token_secret")?).map_err(error)}
fn issuertoken(v:&Value)->R<sdk::IssuerToken>{sdk::IssuerToken::new(text(credentials(v,"issuer")?,"token")?).map_err(error)}
fn monitortoken(v:&Value)->R<sdk::MonitorToken>{sdk::MonitorToken::new(text(credentials(v,"monitor")?,"token")?).map_err(error)}
fn config(v:&Value,token:CancellationToken)->R<sdk::ClientConfig>{
 let mut c=sdk::ClientConfig::new();let mut o=sdk::CallOptions::new().cancellation(token);
 if let Some(x)=v.get("config") {
  if let Some(x)=x.get("base_url"){c=c.base_url(x.as_str().ok_or_else(||failure("configuration","Invalid base URL."))?);}
  if let Some(x)=x.get("ca_pem"){c=c.ca_certificates_pem(x.as_str().ok_or_else(||failure("configuration","Invalid CA."))?.as_bytes().to_vec());}
  if let Some(x)=x.get("trusted_file_origins") {for s in x.as_array().ok_or_else(||failure("configuration","Invalid trusted origins."))?{c=c.trust_file_origin(s.as_str().ok_or_else(||failure("configuration","Invalid origin."))?);}}
  if let Some(x)=x.get("timeout_ms"){let n=x.as_i64().filter(|n|*n>0).ok_or_else(||failure("configuration","Invalid timeout."))?;o=o.timeout(std::time::Duration::from_millis(n as u64));}
  if let Some(x)=x.get("max_response_bytes"){let n=x.as_i64().filter(|n|*n>0&&*n<=16*1024*1024).ok_or_else(||failure("configuration","Worker response limit is 16 MiB."))?;o=o.max_response_bytes(n as usize);}
  if let Some(x)=x.get("max_header_bytes"){let n=x.as_i64().filter(|n|*n>0).ok_or_else(||failure("configuration","Invalid header limit."))?;o=o.max_header_bytes(n as usize);}
 }
 Ok(c.call_options(o))
}
fn file_auth(v:&Value)->R<sdk::FileAuth>{let a=required(v,"file_auth")?;match text(a,"mode")?{"company"=>Ok(sdk::FileAuth::company()),"issuer"=>Ok(sdk::FileAuth::issuer()),"document_token"=>sdk::FileAuth::document_token(text(a,"token")?).map_err(error),"anonymous"=>Ok(sdk::FileAuth::anonymous()),"capability"=>Ok(sdk::FileAuth::public_report()),_=>Err(failure("capability","Unknown file access mode."))}}
fn file(f:sdk::FileResponse)->Value {
 const HEX:&[u8]=b"0123456789abcdef";let mut hex=String::with_capacity(f.bytes().len()*2);for b in f.bytes(){hex.push(HEX[(b>>4) as usize]as char);hex.push(HEX[(b&15)as usize]as char);}
 object(vec![("kind","file".into()),("status",i64::from(f.status()).into()),("media_type",f.media_type().into()),("file_kind",format!("{:?}",f.kind()).into()),("bytes_hex",hex.into())])
}
fn projection_requested(v:&Value)->R<bool> {
 match v.get("projection_hints") {None|Some(Value::Bool(false))=>Ok(false),Some(Value::Bool(true))=>Ok(true),_=>Err(failure("validation","Invalid projection_hints flag."))}
}
fn projection_failure(mut original:Value,sdk_call_completed:bool)->Value {
 if let Some(map)=original.as_object_mut(){map.remove("projection_hints");}
 object(vec![("kind","projection".into()),("message","Projection hints exceed the output frame budget.".into()),("sdk_call_completed",sdk_call_completed.into()),("protected_result",original)])
}
fn with_projection_hints<T:projection::ProjectionHints+?Sized>(typed:&T,mut result:Value,v:&Value)->R<Value> {
 if projection_requested(v)? {
  let indices=match projection::hex(typed){Ok(x)=>x,Err(())=>return Err(projection_failure(result,v.get("action").and_then(Value::as_str)==Some("call")))};
  let hints=object(vec![("format",projection::FORMAT.into()),("metadata_sha256",projection::METADATA_SHA256.into()),("indices_hex",indices.into())]);
  result.as_object_mut().ok_or_else(||failure("protocol","Invalid typed result envelope."))?.insert("projection_hints",hints);
 }
 Ok(result)
}
fn pending(p:sdk::NfsePdfPendingResponse,v:&Value)->R<Value> {
 let status=p.status();let media=p.media_type().to_owned();
 let value=p.payload().to_json().map_err(|_|failure("response_schema","Pending payload projection failed."))?;
 with_projection_hints(p.payload(),object(vec![("kind","pending".into()),("status",i64::from(status).into()),("media_type",media.into()),("value",value)]),v)
}
include!("generated.rs");
// Output uses a separate bounded writer: SDK's 8 MiB request serializer is
// intentionally not applied to a 16 MiB file encoded as hexadecimal.
fn serialize(v:&Value,out:&mut Vec<u8>,depth:usize)->Result<(),()> {
 if depth>68{return Err(())}match v {
 Value::Null=>out.extend_from_slice(b"null"),Value::Bool(b)=>out.extend_from_slice(if *b{b"true"}else{b"false"}),Value::Number(n)=>out.extend_from_slice(n.as_str().as_bytes()),
 Value::String(s)=>{out.push(b'"');for c in s.chars(){match c{'"'=>out.extend_from_slice(b"\\\""),'\\'=>out.extend_from_slice(b"\\\\"),'\n'=>out.extend_from_slice(b"\\n"),'\r'=>out.extend_from_slice(b"\\r"),'\t'=>out.extend_from_slice(b"\\t"),c if c<'\u{20}'=>out.extend_from_slice(format!("\\u{:04x}",c as u32).as_bytes()),c=>{let mut b=[0;4];out.extend_from_slice(c.encode_utf8(&mut b).as_bytes());}}if out.len()>OUTPUT_MAX{return Err(())}}out.push(b'"');},
 Value::Array(a)=>{out.push(b'[');for(i,x)in a.iter().enumerate(){if i>0{out.push(b',')}serialize(x,out,depth+1)?;}out.push(b']');},
 Value::Object(m)=>{out.push(b'{');for(i,(k,x))in m.iter().enumerate(){if i>0{out.push(b',')}serialize(&Value::String(k.into()),out,depth+1)?;out.push(b':');serialize(x,out,depth+1)?;}out.push(b'}');}}
 if out.len()>OUTPUT_MAX{Err(())}else{Ok(())}
}
struct Completed { value:Value, requested:bool, sdk_call_completed:bool }
fn run()->R<Completed>{
 let mut input=std::io::stdin().as_fd().try_clone_to_owned().map(std::fs::File::from).map_err(|_|failure("protocol","Missing input stream."))?;let mut size=[0;4];input.read_exact(&mut size).map_err(|_|failure("protocol","Incomplete frame."))?;
 let n=u32::from_be_bytes(size)as usize;if n==0||n>INPUT_MAX{return Err(failure("request_limit","Frame exceeds 32 MiB."));}
 let mut bytes=vec![0;n];input.read_exact(&mut bytes).map_err(|_|failure("protocol","Incomplete frame."))?;
 let mut v=sdk::json::parse(&bytes).map_err(|_|failure("validation","Invalid exact JSON frame."))?;drop(bytes);
 if integer(&v,"protocol")?!=1{return Err(failure("protocol","Unsupported protocol."));}
 if v.get("action").and_then(Value::as_str)==Some("call")&&v.get("operation").and_then(Value::as_str)==Some("nfeDownloadIbsCbsEventXml"){return Err(failure("capability","Operation not available in this SDK release."));}
 let requested=projection_requested(&v)?;
 for key in ["body","query","path","value"] {
  let encoded=format!("{key}_json");
  if let Some(raw)=v.get(&encoded) {
   if v.get(key).is_some(){return Err(failure("validation","Duplicate encoded payload."));}
   let parsed=sdk::json::parse(raw.as_str().ok_or_else(||failure("validation","Expected encoded JSON text."))?.as_bytes()).map_err(|_|failure("validation","Invalid exact JSON payload."))?;
   v.as_object_mut().ok_or_else(||failure("validation","Expected envelope object."))?.insert(key,parsed);
  }
 }
 let token=CancellationToken::new();if v.get("cancelled").and_then(Value::as_bool)==Some(true){token.cancel();}
 // The controller owns stdin and the atomic token only. It never captures
 // the envelope, credentials, body, response, client or sockets.
 let controller_token=token.clone();std::thread::spawn(move||{let mut b=[0;1];let _=input.read(&mut b);controller_token.cancel();});
 let action=text(&v,"action")?;
 let value=match action{"call"=>dispatch(&v,token),"validate"=>validate(&v),_=>Err(failure("capability","Unknown action."))}?;
 Ok(Completed{value,requested,sdk_call_completed:action=="call"})
}
fn render(result:Result<Completed,Value>)->Vec<u8> {
 let (mut envelope,context)=match result {
  Ok(done)=>(object(vec![("protocol",1.into()),("ok",true.into()),("result",done.value)]),Some((done.requested,done.sdk_call_completed))),
  Err(error)=>(object(vec![("protocol",1.into()),("ok",false.into()),("error",error)]),None)
 };
 let mut bytes=Vec::new();
 if serialize(&envelope,&mut bytes,0).is_err(){
  bytes.clear();
  if let Some((true,completed))=context {
   let original=envelope.as_object_mut().and_then(|m|m.remove("result")).unwrap_or(Value::Null);
   let error=projection_failure(original,completed);
   envelope=object(vec![("protocol",1.into()),("ok",false.into()),("error",error)]);
   if serialize(&envelope,&mut bytes,0).is_err(){
    bytes.clear();let minimal=object(vec![("protocol",1.into()),("ok",false.into()),("error",object(vec![("kind","projection".into()),("message","Protected projection result exceeds the output frame budget.".into()),("sdk_call_completed",completed.into())]))]);
    serialize(&minimal,&mut bytes,0).expect("fixed projection error fits");
   }
  }else{bytes=br#"{"protocol":1,"ok":false,"error":{"kind":"body_limit","message":"Output frame limit exceeded."}}"#.to_vec();}
 }
 bytes
}
fn main(){
 let bytes=render(run());let mut output=std::io::stdout().lock();let _=output.write_all(&(bytes.len()as u32).to_be_bytes()).and_then(|_|output.write_all(&bytes)).and_then(|_|output.flush());
 // As before, single-call process exit ends its token-only stdin controller.
}


#[cfg(test)]
mod worker_projection_tests {
 use super::*;
 #[test]
 fn every_model_keeps_payload_and_root_variant_names_agree_with_indices() {
  let corpus=sdk::json::parse(include_bytes!("../test-data/model-corpus.json")).unwrap();
  let metadata=sdk::json::parse(include_bytes!("../api-metadata.json")).unwrap();
  let cases=corpus.get("cases").unwrap().as_array().unwrap();let mut enums=0;
  for case in cases {
   let model=case.get("model").unwrap().as_str().unwrap();
   let mut request=object(vec![("action","validate".into()),("model",model.into()),("value",case.get("value").unwrap().clone())]);
   let plain=validate(&request).unwrap();
   let plain_bytes=render(Ok(Completed{value:plain.clone(),requested:false,sdk_call_completed:false}));
   request.as_object_mut().unwrap().insert("projection_hints",false);
   assert_eq!(render(Ok(Completed{value:validate(&request).unwrap(),requested:false,sdk_call_completed:false})),plain_bytes);
   request.as_object_mut().unwrap().insert("projection_hints",true);
   let mut projected=validate(&request).unwrap();let hints=projected.as_object_mut().unwrap().remove("projection_hints").unwrap();
   assert_eq!(projected,plain,"{model}");
   assert_eq!(hints.get("format").unwrap().as_str(),Some(projection::FORMAT));assert_eq!(hints.get("metadata_sha256").unwrap().as_str(),Some(projection::METADATA_SHA256));
   let hex=hints.get("indices_hex").unwrap().as_str().unwrap();assert_eq!(hex.len()%2,0);
   if let Some(name)=plain.get("variant").and_then(Value::as_str) {
    enums+=1;let (module,model_name)=model.split_once("::").unwrap();
    let definition=metadata.get("models").unwrap().as_array().unwrap().iter().find(|m|m.get("module").and_then(Value::as_str)==Some(module)&&m.get("name").and_then(Value::as_str)==Some(model_name)).unwrap();
    let index=definition.get("fields").unwrap().as_array().unwrap().iter().position(|f|f.get("name").and_then(Value::as_str)==Some(name)).unwrap();
    assert_eq!(u8::from_str_radix(&hex[..2],16).unwrap() as usize,index,"{model} {name}");
   }
  }
  let models=metadata.get("models").unwrap().as_array().unwrap();let enum_models=models.iter().filter(|m|m.get("kind").and_then(Value::as_str)==Some("enum")).count();
  assert_eq!((cases.len(),enums),(models.len(),enum_models));
 }
 #[test]
 fn projection_frame_overflow_preserves_original_result_and_completion_context() {
  for completed in [false,true] {
   let original=object(vec![("kind","json".into()),("value",object(vec![("private-message","must be preserved, never logged".into())]))]);
   let mut too_large=original.clone();
   too_large.as_object_mut().unwrap().insert("projection_hints",object(vec![("format",projection::FORMAT.into()),("metadata_sha256",projection::METADATA_SHA256.into()),("indices_hex","00".repeat(projection::MAX_INDICES).into())]));
   let bytes=render(Ok(Completed{value:too_large,requested:true,sdk_call_completed:completed}));
   assert!(bytes.len()<4096);let frame=sdk::json::parse(&bytes).unwrap();let error=frame.get("error").unwrap();
   assert_eq!(frame.get("ok"),Some(&Value::Bool(false)));assert_eq!(error.get("kind").and_then(Value::as_str),Some("projection"));
   assert_eq!(error.get("message").and_then(Value::as_str),Some("Projection hints exceed the output frame budget."));
   assert_eq!(error.get("sdk_call_completed"),Some(&Value::Bool(completed)));assert_eq!(error.get("protected_result"),Some(&original));
   assert!(!format!("{error:?}").contains("must be preserved"));
  }
 }
 #[test]
 fn opt_in_flag_is_boolean_and_does_not_change_unrequested_results() {
  assert!(!projection_requested(&object(vec![])).unwrap());
  assert!(!projection_requested(&object(vec![("projection_hints",false.into())])).unwrap());
  assert!(projection_requested(&object(vec![("projection_hints",true.into())])).unwrap());
  assert!(projection_requested(&object(vec![("projection_hints","true".into())])).is_err());
 }
}
