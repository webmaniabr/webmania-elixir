//! Worker-local nominal choices from typed SDK values. No JSON/schema matching.
use webmania_sdk as sdk;

pub(crate) const FORMAT: &str = "variant-preorder-u8-hex-v1";
pub(crate) const MAX_INDICES: usize = crate::OUTPUT_MAX / 2;
pub(crate) struct Indices { values: Vec<u8> }
impl Indices {
    fn new() -> Self { Self { values: Vec::new() } }
    fn push(&mut self, value: u8) -> Result<(), ()> {
        if self.values.len() == MAX_INDICES { return Err(()); }
        self.values.push(value); Ok(())
    }
}
pub(crate) trait ProjectionHints {
    fn write_hints(&self, out: &mut Indices) -> Result<(), ()>;
}
pub(crate) fn collect<T: ProjectionHints + ?Sized>(value: &T) -> Result<Vec<u8>, ()> {
    let mut out = Indices::new(); value.write_hints(&mut out)?; Ok(out.values)
}
pub(crate) fn hex<T: ProjectionHints + ?Sized>(value: &T) -> Result<String, ()> {
    const DIGITS: &[u8; 16] = b"0123456789abcdef";
    let values = collect(value)?; let mut text = String::with_capacity(values.len() * 2);
    for value in values { text.push(DIGITS[(value >> 4) as usize] as char); text.push(DIGITS[(value & 15) as usize] as char); }
    Ok(text)
}
macro_rules! noop { ($($t:ty),*) => {$ (impl ProjectionHints for $t { fn write_hints(&self, _: &mut Indices) -> Result<(), ()> { Ok(()) } })*}; }
noop!((), bool, str, String, i8, i16, i32, i64, isize, u8, u16, u32, u64, usize, sdk::json::Number, sdk::model::Scalar, sdk::json::Value, sdk::json::Map);
impl<T: ProjectionHints> ProjectionHints for Option<T> {
    fn write_hints(&self, out: &mut Indices) -> Result<(), ()> { if let Some(value) = self { value.write_hints(out)?; } Ok(()) }
}
impl<T: ProjectionHints> ProjectionHints for sdk::Nullable<T> {
    fn write_hints(&self, out: &mut Indices) -> Result<(), ()> { if let Self::Value(value) = self { value.write_hints(out)?; } Ok(()) }
}
impl<T: ProjectionHints + ?Sized> ProjectionHints for Box<T> {
    fn write_hints(&self, out: &mut Indices) -> Result<(), ()> { (**self).write_hints(out) }
}
impl<T: ProjectionHints> ProjectionHints for [T] {
    fn write_hints(&self, out: &mut Indices) -> Result<(), ()> { for value in self { value.write_hints(out)?; } Ok(()) }
}
impl<T: ProjectionHints> ProjectionHints for Vec<T> {
    fn write_hints(&self, out: &mut Indices) -> Result<(), ()> { self.as_slice().write_hints(out) }
}
impl<T: ProjectionHints, const N: usize> ProjectionHints for [T; N] {
    fn write_hints(&self, out: &mut Indices) -> Result<(), ()> { self.as_slice().write_hints(out) }
}
impl<T: ProjectionHints> ProjectionHints for std::collections::BTreeMap<String, T> {
    fn write_hints(&self, out: &mut Indices) -> Result<(), ()> { for value in self.values() { value.write_hints(out)?; } Ok(()) }
}
impl<T: ProjectionHints, S: std::hash::BuildHasher> ProjectionHints for std::collections::HashMap<String, T, S> {
    fn write_hints(&self, out: &mut Indices) -> Result<(), ()> { let mut entries: Vec<_> = self.iter().collect(); entries.sort_unstable_by(|a,b| a.0.cmp(b.0)); for (_,value) in entries { value.write_hints(out)?; } Ok(()) }
}
include!("projection_generated.rs");

#[cfg(test)]
mod tests {
    use super::*;
    use sdk::Model;
    #[test]
    fn nominal_55_56_nesting_containers_and_untyped_values() {
        use sdk::models::api1_fiscal::{NfseServiceTaxClass as Union, NfeDocumentLog};
        let raw = sdk::json::parse(br#"{"descricao":"synthetic","tipo":"nfse","local_prestacao":"1"}"#).unwrap();
        let value = Union::from_value(&raw).unwrap();
        assert!(matches!(&value, Union::NfseTaxClassProvider56(_)));
        assert_eq!(collect(&value).unwrap(), [1]);
        let named_null = NfeDocumentLog::Null; assert_eq!(collect(&named_null).unwrap(), [3]);
        assert!(collect(&Option::<Union>::None).unwrap().is_empty());
        assert!(collect(&sdk::Nullable::<Union>::Null).unwrap().is_empty());
        assert_eq!(collect(&Some(sdk::Nullable::Value(Box::new(vec![value.clone(),value.clone()])))).unwrap(), [1,1]);
        let mut sorted = std::collections::BTreeMap::new(); sorted.insert("z".to_owned(), named_null.clone()); sorted.insert("á".to_owned(), NfeDocumentLog::Text("private".into()));
        assert_eq!(collect(&sorted).unwrap(), [3,1]);
        let mut hashed = std::collections::HashMap::new(); hashed.insert("á".to_owned(), NfeDocumentLog::Text("private".into())); hashed.insert("z".to_owned(), named_null);
        assert_eq!(collect(&hashed).unwrap(), [3,1]);
        let raw = sdk::json::parse(br#"{"private-key":{"fakeEnum":true},"future":[{},null]}"#).unwrap();
        assert!(collect(&raw).unwrap().is_empty());
        assert_eq!(hex(&value).unwrap(), "01");
    }
    #[test]
    fn raw_index_budget_matches_maximum_possible_hex_frame_and_never_truncates() {
        let mut out = Indices::new(); for _ in 0..MAX_INDICES { out.push(0).unwrap(); }
        assert_eq!(out.values.len(), MAX_INDICES); assert!(out.push(0).is_err());
        assert_eq!(out.values.len(), MAX_INDICES);
    }
}
