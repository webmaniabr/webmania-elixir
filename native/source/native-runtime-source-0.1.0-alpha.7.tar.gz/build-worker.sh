#!/bin/sh
# Offline Linux source build. The archived 45-byte c-ares submodule marker
# is preserved throughout the direct Cargo build for directory-source checksums.
set -eu
SOURCE_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
RUNTIME="$SOURCE_ROOT/native-runtime"
MARKER="$RUNTIME/vendor/c-ares-sys-13.0.0/c-ares/.git"
SAVED="$RUNTIME/vendor-metadata/c-ares.gitdir"
[ "$(wc -c < "$MARKER" | tr -d ' ')" = 45 ]
[ "$(sha256sum "$MARKER" | cut -d' ' -f1)" = c23f0e2a0d906f4d257a41e2da419cc9f546ad85e6221b4b189c94463557b934 ]
cmp -s "$MARKER" "$SAVED"
python3 "$SOURCE_ROOT/tools/generate-projection.py" --runtime "$RUNTIME" --check
cd "$RUNTIME"
export CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0
export CARGO_PROFILE_RELEASE_DEBUG=0 CARGO_TERM_COLOR=never
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-$RUNTIME/target}"
case "$CARGO_TARGET_DIR" in /*) ;; *) CARGO_TARGET_DIR="$RUNTIME/$CARGO_TARGET_DIR" ;; esac
mkdir -p "$CARGO_TARGET_DIR"
CARGO_TARGET_DIR=$(CDPATH= cd -- "$CARGO_TARGET_DIR" && pwd)
export CARGO_TARGET_DIR
# Normalize source paths embedded by Rust/C; build locations need not match.
export RUSTFLAGS="${RUSTFLAGS:-} --remap-path-prefix=$SOURCE_ROOT=/webmania-worker-source --remap-path-prefix=$CARGO_TARGET_DIR=/webmania-worker-target"
export CFLAGS="${CFLAGS:-} -ffile-prefix-map=$SOURCE_ROOT=/webmania-worker-source -ffile-prefix-map=$CARGO_TARGET_DIR=/webmania-worker-target"
cargo build --offline --locked --release
OUTPUT="${1:-$SOURCE_ROOT/bin/linux-arm64/webmania-native-worker}"
mkdir -p "$(dirname -- "$OUTPUT")"
cp "$CARGO_TARGET_DIR/release/webmania-native-worker" "$OUTPUT"
[ "$(sha256sum "$MARKER" | cut -d' ' -f1)" = c23f0e2a0d906f4d257a41e2da419cc9f546ad85e6221b4b189c94463557b934 ]
sha256sum "$OUTPUT"
